import os
import json
import bpy

bl_info = {
    "name": "blender2rl Camera Exporter",
    "author": "maya",
    "blender": (2, 80, 0),
    "category": "Import-Export",
}


class ExportCameraOperator(bpy.types.Operator):
    bl_idname = "export.camera_animation"
    bl_label = "Export Camera Animation"
    bl_options = {'REGISTER', 'UNDO'}

    filepath: bpy.props.StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        if not self.filepath:
            self.report({'WARNING'}, "No file path specified.")
            return {'CANCELLED'}

        camera = context.scene.camera

        if not camera:
            self.report({'WARNING'}, "No active camera found in the scene.")
            return {'CANCELLED'}

        camera_animation = []

        start_frame = context.scene.frame_start
        end_frame = context.scene.frame_end
        frame_count = end_frame - start_frame + 1
        frame_step = context.scene.frame_step

        for i in range(0, frame_count, frame_step):
            context.scene.frame_set(start_frame + i)

            location = camera.matrix_world.to_translation()
            rotation = camera.matrix_world.to_quaternion()

            camera_animation.append({
                "time": i / context.scene.render.fps,
                "location": [
                    location.x,
                    location.y,
                    location.z,
                ],
                "rotation": [
                    rotation.w,
                    rotation.x,
                    rotation.y,
                    rotation.z,
                ],
                "fov": camera.data.angle
            })

        os.makedirs(os.path.dirname(self.filepath), exist_ok=True)

        with open(self.filepath, 'w') as json_file:
            json.dump(camera_animation, json_file, indent=4)

        self.report({'INFO'}, f"Camera animation exported to: {self.filepath}")
        return {'FINISHED'}

    def invoke(self, context, event):
        default_path = os.path.join(os.getenv('APPDATA'), "bakkesmod", "bakkesmod", "data", "blender2rl", "untitled")
        context.window_manager.fileselect_add(self)
        self.filepath = default_path
        return {'RUNNING_MODAL'}


def menu_func(self, context):
    self.layout.operator(ExportCameraOperator.bl_idname, text="blender2rl")


def register():
    bpy.utils.register_class(ExportCameraOperator)
    bpy.types.TOPBAR_MT_file_export.append(menu_func)


def unregister():
    bpy.utils.unregister_class(ExportCameraOperator)
    bpy.types.TOPBAR_MT_file_export.remove(menu_func)


if __name__ == "__main__":
    register()
